﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FYP_Common
{
    public class Stock
    {
        public int stockCode;
        public string stockName;
        public List<Tick> priceList;
    }
}
