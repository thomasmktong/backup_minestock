﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FYP_GUI_v1
{
    interface Form_Autoseqsible
    {
        Form_Autoseqdef GetSeqDef();
    }
}
